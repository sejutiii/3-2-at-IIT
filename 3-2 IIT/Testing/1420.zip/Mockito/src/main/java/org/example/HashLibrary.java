package org.example;

public class HashLibrary {
    public String getHash(String str)
    {
        str= str.concat("hashed");
        return str;
    }

}
